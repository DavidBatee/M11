<template>
  <div id="app" class="container is-max-desktop mt-5">
    <router-view />
  </div>
</template>

<script>
  export default {
  name: "App",
  };
</script>

<style>
  /* import style bulma */
  @import "~bulma/css/bulma.css";
</style>